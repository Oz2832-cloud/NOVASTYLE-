import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageShell, PageHeader } from "@/components/PageShell";
import { ProductCard } from "@/components/ProductCard";
import { PRODUCTS, CATEGORIES } from "@/lib/products";

type Search = { categoria?: string; q?: string };

export const Route = createFileRoute("/productos")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    categoria: typeof search.categoria === "string" ? search.categoria : undefined,
    q: typeof search.q === "string" ? search.q : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Productos — NOVASTYLE" },
      { name: "description", content: "Catálogo completo NOVASTYLE: hombre, mujer, niños, niñas, calzado, bolsos y accesorios. Precios en Quetzales." },
      { property: "og:title", content: "Productos — NOVASTYLE" },
      { property: "og:description", content: "Explora más de 50 diseños modernos con envío a toda Guatemala." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductosPage,
});

function ProductosPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/productos" });
  const filter = search.categoria ?? "todos";
  const [query, setQuery] = useState(search.q ?? "");
  const [type, setType] = useState("todos");
  const [currentPage, setCurrentPage] = useState(1);
  const PRODUCTS_PER_PAGE = 20;

  const types = useMemo(() => {
    const list = PRODUCTS.filter((p) => filter === "todos" || p.category === filter).map((p) => p.type);
    return ["todos", ...Array.from(new Set(list))];
  }, [filter]);

  const filtered = useMemo(
    () =>
      PRODUCTS.filter(
        (p) =>
          (filter === "todos" || p.category === filter) &&
          (type === "todos" || p.type === type) &&
          (query === "" ||
            p.name.toLowerCase().includes(query.toLowerCase()) ||
            p.type.toLowerCase().includes(query.toLowerCase()) ||
            p.style.toLowerCase().includes(query.toLowerCase())),
      ),
    [filter, query, type],
  );

  const totalPages = Math.ceil(filtered.length / PRODUCTS_PER_PAGE);
  const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const paginatedProducts = filtered.slice(startIndex, startIndex + PRODUCTS_PER_PAGE);

  const setCategory = (key: string) => {
    setType("todos");
    setCurrentPage(1);
    navigate({ search: { categoria: key === "todos" ? undefined : key, q: query || undefined } });
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getPaginationNumbers = () => {
    const pages = [];
    const maxPages = 5;
    if (totalPages <= maxPages) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= 3; i++) pages.push(i);
        pages.push("...");
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1);
        pages.push("...");
        for (let i = totalPages - 2; i <= totalPages; i++) pages.push(i);
      } else {
        pages.push(1);
        pages.push("...");
        pages.push(currentPage - 1);
        pages.push(currentPage);
        pages.push(currentPage + 1);
        pages.push("...");
        pages.push(totalPages);
      }
    }
    return pages;
  };

  return (
    <PageShell>
      <PageHeader eyebrow="Catálogo" title="Productos" subtitle="Todo lo que necesitas para lucir tu mejor estilo. Filtra por categoría y encuentra tu look." />
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((c) => (
                <button
                  key={c.key}
                  onClick={() => setCategory(c.key)}
                  className={`rounded-full px-5 py-2 text-sm font-semibold transition-all ${filter === c.key ? "bg-gradient-brand text-white shadow-glow" : "bg-muted text-foreground hover:bg-secondary"}`}
                >
                  {c.label}
                </button>
              ))}
            </div>
            <input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setCurrentPage(1); }}
              placeholder="Buscar producto…"
              className="w-full max-w-xs rounded-full border border-input bg-white px-5 py-2.5 text-sm focus:border-nova-purple focus:outline-none"
            />
          </div>

          {types.length > 2 && (
            <div className="mb-8 flex flex-wrap gap-2">
              {types.map((t) => (
                <button
                  key={t}
                  onClick={() => { setType(t); setCurrentPage(1); }}
                  className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${type === t ? "border-transparent bg-nova-purple text-white" : "border-border text-muted-foreground hover:border-nova-purple hover:text-nova-purple"}`}
                >
                  {t === "todos" ? "Todos los tipos" : t}
                </button>
              ))}
            </div>
          )}

          <p className="mb-6 text-sm text-muted-foreground">Mostrando {startIndex + 1}–{Math.min(startIndex + PRODUCTS_PER_PAGE, filtered.length)} de {filtered.length} productos</p>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {paginatedProducts.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
          {filtered.length === 0 && <p className="mt-16 text-center text-muted-foreground">Sin resultados para tu búsqueda.</p>}

          {totalPages > 1 && (
            <div className="mt-12 flex justify-center items-center gap-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-4 py-2 rounded-full border border-nova-purple text-nova-purple font-semibold hover:bg-nova-purple hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                ← Anterior
              </button>
              <div className="flex gap-1">
                {getPaginationNumbers().map((page, idx) => (
                  <button
                    key={idx}
                    onClick={() => typeof page === "number" && handlePageChange(page)}
                    disabled={page === "..."}
                    className={`px-3 py-2 rounded-full font-semibold transition ${
                      page === currentPage
                        ? "bg-gradient-brand text-white shadow-glow"
                        : page === "..."
                        ? "cursor-default text-muted-foreground"
                        : "border border-border text-foreground hover:border-nova-purple hover:text-nova-purple"
                    }`}
                  >
                    {page}
                  </button>
                ))}
              </div>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-4 py-2 rounded-full border border-nova-purple text-nova-purple font-semibold hover:bg-nova-purple hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                Siguiente →
              </button>
            </div>
          )}
        </div>
      </section>
    </PageShell>
  );
}

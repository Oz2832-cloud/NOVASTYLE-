# NOVASTYLE - correcciones realizadas

- Catálogo limitado a 300 productos en tiempo de ejecución, conservando los productos base y variantes hasta alcanzar el total.
- Categorías Skincare, Cuidado personal y Maquillaje incorporadas al tipado, filtros y catálogo.
- Paginación numérica de 24 productos por página; se eliminó el flujo de "Cargar más productos".
- Fechas editoriales del Blog reorganizadas dentro del periodo 27 de julio al 5 de agosto de 2026.
- Bitácora reescrita para documentar la creación del Blog, sin nombres de proveedores de hosting.
- Tres artículos adicionales incorporados al Blog.
- Seis videos solicitados incorporados a la sección de videos del Blog.
- Se conservaron los tres botones de Blogs existentes y se agregaron únicamente Luis y Dulce.
- Logo existente conservado en public/novastyle-logo.png y referenciado desde /novastyle-logo.png.
- Configuración Netlify existente conservada: npm run build, publish dist, Node 22, NITRO_PRESET=netlify.

## Nota de verificación
No fue posible completar `npm install` en el entorno de revisión dentro del tiempo disponible, por lo que el build no pudo certificarse aquí. Antes de publicar, ejecutar `npm install` y `npm run build` en un entorno con acceso normal al registro de paquetes.
